import React, { useState } from "react";
import '../../css/OptVerification/otpVerification.css';
import { Card, CardContent, Button, Typography } from "@mui/material";
import MobilePng from '../../images/assets/otpMobile.png'
import OTPInput, { ResendOTP } from "otp-input-react";
import { makeStyles } from "@material-ui/styles";
import { useSelector } from "react-redux";
import OtpServices from "../../service/OtpService";
import { toast } from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { userLoginAction } from "../../Redux/actions/auth";
import ConsentSerivce from "../../service/ConsentService";
import UserServices from "../../service/UserService";
import CompanyServices from "../../service/Company";
const useStyles = makeStyles((theme) => ({
    menuItem: {
        marginTop: '11px',
        //  display:'flex-root',

        display: 'flex',
        justifyContent: 'space-between'
    },
}));

export default function OtpVerificationMainFounder({ email, founderLoginData, isNewCreate }) {
    const [OTP, setOTP] = useState("");
    const [WarnMsg, setWarnMsg] = useState(false)
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const classes = useStyles();
    let loginType = localStorage.getItem('loginType')
    const { userMail } = useSelector((state) => state.userInfo)
    const { userData } = useSelector((state) => state.loginData)
    const { founderData } = useSelector(state => state.founderSignUpData)

    console.log(founderData)
    const notify = (data) => {
        toast.error(data,{
            position: "top-right",
            style: {
              borderRadius: "3px",
              background: "red",
              color: "#fff",
            },
          })
    }
    const notifySuccess = (data) => {
        toast.success(data,{
            position: "top-right",
            style: {
              borderRadius: "3px",
              background: "green",
              color: "#fff",
            },
          })
    }
    const handleResendOtp = () => {
        const usernames = userMail ? userMail : userData.email
        try {
            OtpServices.ResendOtpMail(usernames).then(
                (response) => {
                    console.log(response?.data.message)
                })
        }
        catch {
            notify("Try after few minutes")
        }
    }
    console.log(loginType)
    const handleSubmit = (e) => {
        e.preventDefault();
        const usernames = userMail ? userMail : userData.email
        let data = { email: usernames, otp: OTP }
        try {
            OtpServices.VerifyEmailOtp({ otp: data.otp, email }).then(
                (response) => {
                    console.log(response.data)
                    if (response.data.status !== 'false') {
                        localStorage.setItem("access_token", response.data.access_token)
                        localStorage.setItem("company_id",response.data.data.company_id)
                        console.log(response.data)
                        dispatch(userLoginAction(founderLoginData ? founderLoginData : response.data.data))
                        isNewCreate
                            ? CompanyServices.createCompany({ user_id: response.data.data.id, ...founderData }).then(
                                (response) => {
                                    if (response.data) {
                                        console.log("founder created")
                                        navigate('/dashboard-founder/e-signin')
                                    } else {
                                        console.log("failed! founder create")
                                        toast.error("Something went wrong! please try again later",{
                                            position: "top-right",
                                            style: {
                                              borderRadius: "3px",
                                              background: "red",
                                              color: "#fff",
                                            },
                                          })
                                    }
                                }
                            )
                            : navigate('/dashboard-founder/e-signin')
                    }
                    else {
                        setOTP('')
                        setWarnMsg(true)
                    }

                })
        }
        catch {
            notify("Try after few minutes")
        }

    }

    const renderButton = buttonProps => {
        return <button style={{ background: 'none', border: 'none', float: 'right', marginRight: '20px', cursor: 'pointer' }} {...buttonProps}>Resend</button>;
    };
    const renderTime = remainingTime => {
        return <span style={{ color: '#777777', fontSize:'14px' }}>Resend after {remainingTime} s</span>;
    };
    return (
        <div className="verification-container ">
            <div className="get-started-section">
                <span className="get-started-heading">OTP Verification</span>
                <Card className="card-get-started">
                    <CardContent>
                        <div className="otp-verify-container">
                            <img src={MobilePng} className="otp-verification-image"></img>
                        </div>
                        <span className="get-started-subheading">We’ve sent an OTP to your registered email ID. Enter it here to verify your email and continue!</span>
                        <div className="otp-verification-section">
                            <OTPInput
                                value={OTP}
                                onChange={setOTP}
                                autoFocus
                                OTPLength={6}
                                otpType="number"
                                disabled={false}
                                // secure
                                inputStyles={{ width: '35px', outline: 'none', height: '35px', background: '#F4F4F4 0% 0% no-repeat padding-box', border: 'none', fontWeight: '600', fontSize: '20px' }}
                            />
                            {WarnMsg &&
                                <Typography style={{ fontSize: '14px', textAlign: 'left', color: '#FF9494', paddingTop: '10px' }}>Invalid OTP! please enter correct OTP.</Typography>}
                            <ResendOTP maxTime={90} onResendClick={() => handleResendOtp()} className={classes.menuItem} renderTime={renderTime} renderButton={renderButton} disable={false} />
                        </div>

                        <button className="sign-up-btn" onClick={handleSubmit} > {loginType === 'new' ? "Sign Up" : "Sign In"}</button>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}