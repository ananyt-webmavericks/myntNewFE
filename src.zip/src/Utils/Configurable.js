export const ClientId = '1053304903749-jl5p5f3sjsc3nei2oa8jbiuo2od00tib.apps.googleusercontent.com';
export const AppId = "1326249041547634";
export const Base_Url = 'https://mynt-dev.webmavericks.org';